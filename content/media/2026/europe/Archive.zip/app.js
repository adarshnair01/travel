/* ── Interactive itinerary ─────────────────────────────────────────────── */
(() => {
  "use strict";

  const $ = (sel, root = document) => root.querySelector(sel);
  const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];
  const byId = (id) => document.getElementById(id);
  const country = (code) => TRIP.countries.find((c) => c.code === code) || {};

  const fmtDate = (iso, opts) =>
    new Date(iso + "T00:00:00").toLocaleDateString("en-GB", opts || { day: "numeric", month: "short" });
  const weekday = (iso) => new Date(iso + "T00:00:00").toLocaleDateString("en-GB", { weekday: "short" });

  /* ── Icons ───────────────────────────────────────────────────────────── */
  const S = (d, extra = "") =>
    `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"
      stroke-linecap="round" stroke-linejoin="round" ${extra}>${d}</svg>`;

  const ICON = {
    train: S('<rect x="5" y="3" width="14" height="13" rx="3"/><path d="M5 10h14M9 20l-1.5 2M15 20l1.5 2M8 16h8"/><circle cx="9" cy="13" r=".6" fill="currentColor"/><circle cx="15" cy="13" r=".6" fill="currentColor"/>'),
    bus: S('<rect x="3" y="4" width="18" height="13" rx="3"/><path d="M3 11h18M7 17v2M17 17v2"/>'),
    plane: S('<path d="M2 13l19-7-7 19-2.5-7.5L2 13Z"/>'),
    day: S('<path d="M4 8h13a4 4 0 0 1 0 8H7"/><path d="m7 5 3 3-3 3M10 19l-3-3 3-3"/>'),
    bed: S('<path d="M3 18v-7h12a4 4 0 0 1 4 4v3M3 18h18M3 11V7"/><circle cx="7.5" cy="8.5" r="1.6"/>'),
    globe: S('<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c2.6 3 2.6 15 0 18-2.6-3-2.6-15 0-18Z"/>'),
    pin: S('<path d="M12 21s7-5.6 7-11a7 7 0 1 0-14 0c0 5.4 7 11 7 11Z"/><circle cx="12" cy="10" r="2.6"/>'),
    mountain: S('<path d="M2 19h20M5 19l6-11 3 5.5M11.5 13l2-3 5 9"/>'),
    town: S('<path d="M3 21V9l5-4 5 4v12M13 21V13h8v8M3 21h18"/><path d="M16.5 17h1.5"/>'),
    star: S('<path d="m12 3.5 2.6 5.4 5.9.8-4.3 4.2 1 5.9-5.2-2.8-5.2 2.8 1-5.9L3.5 9.7l5.9-.8L12 3.5Z"/>'),
    clock: S('<circle cx="12" cy="12" r="9"/><path d="M12 7.5V12l3 2"/>'),
    check: S('<path d="m4 12.5 5 5L20 6.5"/>'),
    sparkle: S('<path d="M12 3v6M12 15v6M3 12h6M15 12h6"/>'),
  };

  /* ── Card artwork per theme ──────────────────────────────────────────── */
  const ART = {
    lake: `<path class="a-sky" d="M0 0h400v150H0z"/><path class="a-m2" d="M0 108 70 52l58 44 52-34 66 50 60-30 94 46v22H0z"/>
      <path class="a-m1" d="M0 122 62 84l54 30 66-22 58 34 70-24 90 34v14H0z"/>
      <path class="a-water" d="M0 136h400v64H0z"/><path class="a-glow" d="M150 136h100v64H150z"/>
      <g class="a-town"><rect x="118" y="112" width="16" height="26" rx="2"/><rect x="140" y="104" width="13" height="34" rx="2"/><rect x="160" y="116" width="18" height="22" rx="2"/><rect x="248" y="110" width="14" height="28" rx="2"/><rect x="268" y="118" width="18" height="20" rx="2"/></g>
      <g class="a-ripple"><path d="M60 158h70M40 172h110M210 152h90M240 178h120M120 188h150"/></g>`,
    peak: `<path class="a-sky" d="M0 0h400v150H0z"/><path class="a-m3" d="M0 118 96 34l64 54 56-40 76 62 56-34 52 42v42H0z"/>
      <path class="a-snow" d="M96 34l30 26-16 6-14-8-12 10-18-8z"/><path class="a-snow" d="M292 42l24 20-14 6-12-6-10 8-16-6z"/>
      <path class="a-m1" d="M0 150 70 116l64 26 60-18 70 30 66-22 70 26v42H0z"/><path class="a-ground" d="M0 176h400v24H0z"/>
      <g class="a-tree"><path d="M40 176l10-24 10 24zM70 178l8-20 8 20zM320 176l10-22 10 22zM352 178l8-18 8 18z"/></g>`,
    rail: `<path class="a-sky" d="M0 0h400v150H0z"/><path class="a-m2" d="M0 112 84 44l60 48 62-32 70 54 58-28 66 40v46H0z"/>
      <path class="a-m1" d="M0 144 76 110l58 24 66-16 62 26 68-18 70 22v44H0z"/><path class="a-ground" d="M0 172h400v28H0z"/>
      <g class="a-rail"><path d="M-10 190 410 150"/><path d="M-10 200 410 160"/>
      <path d="M20 196v-9M70 191v-9M120 186v-9M170 181v-9M220 176v-9M270 171v-9M320 166v-9M370 161v-9"/></g>
      <g class="a-carriage"><rect x="150" y="128" width="60" height="24" rx="6"/><rect x="212" y="130" width="52" height="22" rx="5"/>
      <rect x="158" y="134" width="14" height="9" rx="2" class="a-win"/><rect x="178" y="134" width="14" height="9" rx="2" class="a-win"/>
      <rect x="220" y="135" width="13" height="8" rx="2" class="a-win"/><rect x="240" y="135" width="13" height="8" rx="2" class="a-win"/></g>`,
    city: `<path class="a-sky" d="M0 0h400v160H0z"/>
      <g class="a-skyline"><rect x="20" y="96" width="34" height="70" rx="3"/><rect x="62" y="70" width="26" height="96" rx="3"/>
      <rect x="96" y="110" width="40" height="56" rx="3"/><path class="a-dome" d="M156 110c0-22 18-38 22-52 4 14 22 30 22 52z"/>
      <rect x="152" y="108" width="52" height="58" rx="3"/><rect x="212" y="84" width="30" height="82" rx="3"/>
      <rect x="250" y="104" width="44" height="62" rx="3"/><rect x="302" y="76" width="24" height="90" rx="3"/>
      <rect x="334" y="112" width="42" height="54" rx="3"/></g>
      <g class="a-lit"><rect x="28" y="106" width="6" height="8"/><rect x="42" y="106" width="6" height="8"/><rect x="70" y="82" width="6" height="8"/>
      <rect x="70" y="100" width="6" height="8"/><rect x="220" y="96" width="6" height="8"/><rect x="220" y="114" width="6" height="8"/>
      <rect x="308" y="88" width="6" height="8"/><rect x="346" y="124" width="6" height="8"/><rect x="262" y="118" width="6" height="8"/></g>
      <path class="a-ground" d="M0 166h400v34H0z"/>`,
    water: `<path class="a-sky" d="M0 0h400v120H0z"/><path class="a-m2" d="M0 100 90 48l70 42 66-26 80 44 94-32v40H0z"/>
      <path class="a-cliff" d="M0 116h150l14 30H0z"/><path class="a-cliff" d="M400 116H250l-14 30h164z"/>
      <g class="a-fall"><path d="M158 120c6 26 2 44-4 62M172 120c6 26 4 46-2 64M186 120c5 26 3 46-3 64M200 120c6 26 4 44-2 62M214 120c6 26 2 44-4 62M228 120c5 26 3 44-3 62"/></g>
      <path class="a-water" d="M0 176h400v24H0z"/><g class="a-spray"><circle cx="176" cy="176" r="12"/><circle cx="200" cy="182" r="16"/><circle cx="226" cy="176" r="11"/></g>`,
    town: `<path class="a-sky" d="M0 0h400v150H0z"/><path class="a-m2" d="M0 104 88 56l66 40 70-24 76 42 100-28v36H0z"/>
      <g class="a-arena"><path d="M118 168V116a52 26 0 0 1 104 0v52z"/></g>
      <g class="a-arch"><rect x="132" y="132" width="14" height="24" rx="7"/><rect x="156" y="132" width="14" height="24" rx="7"/>
      <rect x="180" y="132" width="14" height="24" rx="7"/><rect x="204" y="132" width="14" height="24" rx="7"/>
      <rect x="138" y="100" width="12" height="20" rx="6"/><rect x="166" y="96" width="12" height="20" rx="6"/><rect x="194" y="100" width="12" height="20" rx="6"/></g>
      <g class="a-town"><rect x="34" y="120" width="30" height="48" rx="2"/><rect x="72" y="108" width="24" height="60" rx="2"/>
      <rect x="252" y="112" width="28" height="56" rx="2"/><rect x="290" y="124" width="34" height="44" rx="2"/><rect x="332" y="114" width="26" height="54" rx="2"/></g>
      <path class="a-ground" d="M0 168h400v32H0z"/>`,
    baroque: `<path class="a-sky" d="M0 0h400v150H0z"/><path class="a-m2" d="M0 96 82 44l64 40 70-22 74 40 110-26v32H0z"/>
      <g class="a-skyline"><rect x="150" y="96" width="100" height="70" rx="2"/>
      <rect x="146" y="70" width="20" height="96" rx="2"/><rect x="234" y="70" width="20" height="96" rx="2"/>
      <path class="a-dome" d="M176 96c0-20 16-30 24-44 8 14 24 24 24 44z"/></g>
      <g class="a-roof"><path d="M146 70l10-22 10 22zM234 70l10-22 10 22z"/><circle cx="200" cy="46" r="4"/></g>
      <g class="a-lit"><rect x="152" y="120" width="8" height="14"/><rect x="172" y="120" width="8" height="14"/>
      <rect x="220" y="120" width="8" height="14"/><rect x="240" y="120" width="8" height="14"/></g>
      <g class="a-town"><rect x="40" y="120" width="28" height="46" rx="2"/><rect x="76" y="112" width="22" height="54" rx="2"/>
      <rect x="300" y="116" width="26" height="50" rx="2"/><rect x="334" y="126" width="30" height="40" rx="2"/></g>
      <path class="a-ground" d="M0 166h400v34H0z"/>
      <g class="a-garden"><rect x="30" y="176" width="100" height="16" rx="3"/><rect x="270" y="176" width="100" height="16" rx="3"/></g>`,
    castle: `<path class="a-sky" d="M0 0h400v150H0z"/><path class="a-m2" d="M0 110 84 46l70 46 62-26 84 50 100-30v34H0z"/>
      <g class="a-castle"><rect x="150" y="94" width="100" height="72" rx="2"/>
      <rect x="140" y="74" width="22" height="92" rx="2"/><rect x="238" y="66" width="24" height="100" rx="2"/><rect x="192" y="58" width="18" height="108" rx="2"/>
      <path class="a-roof" d="M140 74l11-24 11 24zM238 66l12-26 12 26zM192 58l9-26 9 26z"/>
      <g class="a-win"><rect x="166" y="112" width="10" height="18" rx="5"/><rect x="186" y="112" width="10" height="18" rx="5"/>
      <rect x="206" y="112" width="10" height="18" rx="5"/><rect x="226" y="112" width="10" height="18" rx="5"/></g></g>
      <g class="a-tree"><path d="M46 166l12-28 12 28zM82 168l10-24 10 24zM316 166l12-26 12 26zM352 168l10-22 10 22z"/></g>
      <path class="a-ground" d="M0 166h400v34H0z"/>`,
  };

  const artFor = (theme) =>
    `<svg class="card-art" viewBox="0 0 400 200" preserveAspectRatio="xMidYMid slice" aria-hidden="true">${
      ART[theme] || ART.city
    }</svg>`;

  /* ── Static sections ─────────────────────────────────────────────────── */
  function renderStatics() {
    byId("flagRow").innerHTML = TRIP.countries
      .map((c) => `<span class="flag-pill"><i>${c.flag}</i>${c.name}</span>`)
      .join("");

    byId("glance").innerHTML = TRIP.glance
      .map(
        (g) => `<div class="glance-cell reveal">
          <span class="glance-ico">${ICON[g.icon] || ICON.star}</span>
          <b>${g.value}</b><span class="glance-label">${g.label}</span>
        </div>`
      )
      .join("");

    byId("highlightGrid").innerHTML = TRIP.highlights
      .map(
        (h) => `<article class="card highlight reveal">
          <span class="hl-ico">${ICON[h.icon] || ICON.star}</span>
          <h3>${h.title}</h3><p>${h.text}</p>
        </article>`
      )
      .join("");

    byId("tipsList").innerHTML = TRIP.tips
      .map((t) => `<li><span class="tick">${ICON.check}</span>${t}</li>`)
      .join("");

    byId("travelTimeList").innerHTML = TRIP.travelTime
      .map((t) => `<li><b>${t.label}</b><span>${t.value}</span></li>`)
      .join("");

    byId("seqList").innerHTML = TRIP.places
      .filter((p) => p.day)
      .map(
        (p) =>
          `<li><button type="button" data-seq="${p.day}"><em>${p.day}</em>${p.name}${
            p.side ? '<i class="seq-side">day trip</i>' : ""
          }</button></li>`
      )
      .join("");
  }

  /* ── Packing checklist (localStorage) ────────────────────────────────── */
  const PACK_KEY = "europe2026.pack";
  let packed = new Set(JSON.parse(localStorage.getItem(PACK_KEY) || "[]"));

  function renderPack() {
    byId("packList").innerHTML = TRIP.packing
      .map(
        (item, i) => `<li>
          <label class="check ${packed.has(String(i)) ? "is-done" : ""}">
            <input type="checkbox" data-pack="${i}" ${packed.has(String(i)) ? "checked" : ""} />
            <span class="box">${ICON.check}</span><span class="txt">${item}</span>
          </label></li>`
      )
      .join("");
    updatePackMeter();
  }

  function updatePackMeter() {
    const total = TRIP.packing.length;
    const done = packed.size;
    byId("packCount").textContent = `${done} / ${total}`;
    byId("packBar").style.width = `${(done / total) * 100}%`;
  }

  byId("packList").addEventListener("change", (e) => {
    const box = e.target.closest("[data-pack]");
    if (!box) return;
    const id = box.dataset.pack;
    box.checked ? packed.add(id) : packed.delete(id);
    box.closest(".check").classList.toggle("is-done", box.checked);
    localStorage.setItem(PACK_KEY, JSON.stringify([...packed]));
    updatePackMeter();
  });

  byId("resetPack").addEventListener("click", () => {
    packed = new Set();
    localStorage.removeItem(PACK_KEY);
    renderPack();
  });

  /* ── Day cards ───────────────────────────────────────────────────────── */
  const state = { view: "grid", q: "", countries: new Set() };

  function dayHaystack(d) {
    return [
      d.city,
      d.subtitle,
      country(d.country).name,
      d.stay,
      ...(d.activities || []),
      ...(d.schedule || []).map((s) => s.text),
      ...(d.legs || []).map((l) => l.text),
    ]
      .join(" ")
      .toLowerCase();
  }

  function visibleDays() {
    return TRIP.days.filter((d) => {
      if (state.countries.size && !state.countries.has(d.country)) return false;
      if (state.q && !dayHaystack(d).includes(state.q)) return false;
      return true;
    });
  }

  function cardHTML(d) {
    const c = country(d.country);
    const bullets = d.schedule
      ? d.schedule
          .map((s) => `<li class="timed"><b>${s.time}</b><span>${s.text}</span></li>`)
          .join("")
      : (d.activities || []).map((a) => `<li>${a}</li>`).join("");

    return `<article class="card day-card reveal" data-day="${d.n}" tabindex="0" role="button"
        aria-label="Day ${d.n}, ${d.city}. Open details.">
        <div class="card-media theme-${d.theme}">
          ${artFor(d.theme)}
          <span class="day-badge">${String(d.n).padStart(2, "0")}</span>
          <span class="date-badge">${fmtDate(d.date)} · ${weekday(d.date)}</span>
          ${d.badge ? `<span class="tour-badge">${d.badge}</span>` : ""}
        </div>
        <div class="card-body">
          <header class="card-title">
            <h3>${d.city}</h3>
            <span class="country-tag" title="${c.name}">${c.flag} ${c.code}</span>
          </header>
          <p class="card-sub">${d.subtitle}</p>
          <ul class="bullets">${bullets}</ul>
        </div>
        <footer class="card-foot">
          <span class="stay">${ICON.bed}${d.stay ? `Stay: ${d.stay}` : "Departure day"}</span>
          <span class="legs">${(d.legs || [])
            .map((l) => `<i title="${l.text}">${ICON[l.mode] || ICON.train}</i>`)
            .join("")}</span>
        </footer>
      </article>`;
  }

  function timelineHTML(d) {
    const c = country(d.country);
    const items = d.schedule
      ? d.schedule.map((s) => `<li class="timed"><b>${s.time}</b><span>${s.text}</span></li>`).join("")
      : (d.activities || []).map((a) => `<li>${a}</li>`).join("");

    return `<article class="tl-row reveal" data-day="${d.n}" tabindex="0" role="button"
        aria-label="Day ${d.n}, ${d.city}. Open details.">
        <div class="tl-rail"><span class="tl-dot">${d.n}</span></div>
        <div class="card tl-card theme-${d.theme}">
          <div class="tl-head">
            <div>
              <p class="tl-date">${fmtDate(d.date, { weekday: "long", day: "numeric", month: "long" })}</p>
              <h3>${d.city} <span class="country-tag">${c.flag} ${c.code}</span></h3>
              <p class="card-sub">${d.subtitle}</p>
            </div>
            <span class="tl-thumb theme-${d.theme}">${artFor(d.theme)}</span>
          </div>
          <ul class="bullets">${items}</ul>
          <div class="tl-meta">
            <span class="stay">${ICON.bed}${d.stay ? `Stay: ${d.stay}` : "Departure day"}</span>
            ${(d.legs || [])
              .map(
                (l) =>
                  `<span class="leg-chip">${ICON[l.mode] || ICON.train}${l.text}${
                    l.duration ? ` · ${l.duration}` : ""
                  }</span>`
              )
              .join("")}
          </div>
        </div>
      </article>`;
  }

  function renderDays() {
    const days = visibleDays();
    const grid = byId("dayGrid");
    grid.classList.toggle("is-timeline", state.view === "timeline");
    grid.innerHTML = days
      .map((d) => (state.view === "grid" ? cardHTML(d) : timelineHTML(d)))
      .join("");
    byId("emptyState").hidden = days.length > 0;
    observeReveals();
    syncMapDim(days.map((d) => d.n));
  }

  byId("dayGrid").addEventListener("click", (e) => {
    const host = e.target.closest("[data-day]");
    if (host) openDay(+host.dataset.day);
  });
  byId("dayGrid").addEventListener("keydown", (e) => {
    if (e.key !== "Enter" && e.key !== " ") return;
    const host = e.target.closest("[data-day]");
    if (!host) return;
    e.preventDefault();
    openDay(+host.dataset.day);
  });

  /* ── Toolbar: search, country chips, view toggle ─────────────────────── */
  byId("countryChips").innerHTML = TRIP.countries
    .map(
      (c) =>
        `<button type="button" class="chip" data-country="${c.code}"><i>${c.flag}</i>${c.name}
          <em>${TRIP.days.filter((d) => d.country === c.code).length}</em></button>`
    )
    .join("");

  byId("countryChips").addEventListener("click", (e) => {
    const chip = e.target.closest("[data-country]");
    if (!chip) return;
    const code = chip.dataset.country;
    state.countries.has(code) ? state.countries.delete(code) : state.countries.add(code);
    chip.classList.toggle("is-on", state.countries.has(code));
    renderDays();
  });

  const search = byId("search");
  search.addEventListener("input", () => {
    state.q = search.value.trim().toLowerCase();
    renderDays();
  });

  $$(".view-toggle button").forEach((btn) =>
    btn.addEventListener("click", () => {
      $$(".view-toggle button").forEach((b) => b.classList.toggle("is-active", b === btn));
      state.view = btn.dataset.view;
      renderDays();
    })
  );

  byId("clearFilters").addEventListener("click", () => {
    state.q = "";
    state.countries.clear();
    search.value = "";
    $$("[data-country]").forEach((c) => c.classList.remove("is-on"));
    renderDays();
  });

  /* ── Modal ───────────────────────────────────────────────────────────── */
  const modal = byId("modal");
  let openIndex = -1;

  function openDay(n) {
    const i = TRIP.days.findIndex((d) => d.n === n);
    if (i < 0) return;
    openIndex = i;
    const d = TRIP.days[i];
    const c = country(d.country);

    byId("modalDayNum").textContent = String(d.n).padStart(2, "0");
    byId("modalDate").textContent = fmtDate(d.date, {
      weekday: "long",
      day: "numeric",
      month: "long",
      year: "numeric",
    });
    byId("modalCity").textContent = d.city;
    byId("modalSub").innerHTML = `${d.subtitle} <span class="country-tag">${c.flag} ${c.name}</span>`;
    byId("modalHero").className = `modal-hero theme-${d.theme}`;

    const plan = d.schedule
      ? `<ol class="sched">${d.schedule
          .map((s) => `<li><span class="s-time">${ICON.clock}${s.time}</span><span>${s.text}</span></li>`)
          .join("")}</ol>`
      : `<ul class="bullets big">${(d.activities || []).map((a) => `<li>${a}</li>`).join("")}</ul>`;

    byId("modalBody").innerHTML = `
      <div class="modal-art theme-${d.theme}">${artFor(d.theme)}</div>
      <section class="m-block">
        <h4>${d.schedule ? "Schedule" : "Plan for the day"}</h4>
        ${plan}
      </section>
      <section class="m-block">
        <h4>Getting there</h4>
        <ul class="leg-list">${(d.legs || [])
          .map(
            (l) => `<li><span class="leg-ico ${l.mode}">${ICON[l.mode] || ICON.train}</span>
              <span><b>${l.text}</b>${l.duration ? `<em>${l.duration}</em>` : ""}</span></li>`
          )
          .join("")}</ul>
      </section>
      <section class="m-block">
        <h4>Overnight</h4>
        <p class="stay-line">${ICON.bed}${d.stay ? `<b>${d.stay}</b>` : "<b>Flying home</b>"}</p>
      </section>
      ${d.note ? `<aside class="m-note">${ICON.sparkle}<p>${d.note}</p></aside>` : ""}`;

    byId("modalCounter").textContent = `Day ${d.n} of ${TRIP.days.length}`;
    byId("prevDay").disabled = i === 0;
    byId("nextDay").disabled = i === TRIP.days.length - 1;

    modal.hidden = false;
    document.body.classList.add("no-scroll");
    requestAnimationFrame(() => modal.classList.add("is-open"));
    byId("modalClose").focus();
    history.replaceState(null, "", `#day-${d.n}`);
  }

  function closeModal() {
    modal.classList.remove("is-open");
    document.body.classList.remove("no-scroll");
    setTimeout(() => (modal.hidden = true), 200);
    openIndex = -1;
    history.replaceState(null, "", location.pathname + location.search);
  }

  const step = (delta) => {
    const next = openIndex + delta;
    if (next >= 0 && next < TRIP.days.length) openDay(TRIP.days[next].n);
  };

  byId("modalClose").addEventListener("click", closeModal);
  byId("prevDay").addEventListener("click", () => step(-1));
  byId("nextDay").addEventListener("click", () => step(1));
  modal.addEventListener("click", (e) => {
    if (e.target === modal) closeModal();
  });

  document.addEventListener("keydown", (e) => {
    const typing = /^(INPUT|TEXTAREA)$/.test(document.activeElement.tagName);
    if (modal.hidden === false) {
      if (e.key === "Escape") closeModal();
      if (e.key === "ArrowLeft") step(-1);
      if (e.key === "ArrowRight") step(1);
      return;
    }
    if (typing) return;
    if (e.key === "/") {
      e.preventDefault();
      search.focus();
    }
    if (e.key.toLowerCase() === "t") toggleTheme();
  });

  /* ── Route map ───────────────────────────────────────────────────────── */
  const MAP = { w: 1000, h: 620, pad: 66 };

  function project() {
    // Mercator y, expressed in degrees so it shares units with longitude.
    const merc = (lat) =>
      (Math.log(Math.tan(Math.PI / 4 + (lat * Math.PI) / 180 / 2)) * 180) / Math.PI;
    const xs = TRIP.places.map((p) => p.lon);
    const ys = TRIP.places.map((p) => merc(p.lat));
    const [x0, x1] = [Math.min(...xs), Math.max(...xs)];
    const [y0, y1] = [Math.min(...ys), Math.max(...ys)];
    const sx = (MAP.w - MAP.pad * 2) / (x1 - x0);
    const sy = (MAP.h - MAP.pad * 2) / (y1 - y0);
    const s = Math.min(sx, sy);
    const ox = (MAP.w - (x1 - x0) * s) / 2;
    const oy = (MAP.h - (y1 - y0) * s) / 2;
    return (p) => ({
      x: ox + (p.lon - x0) * s,
      y: MAP.h - (oy + (merc(p.lat) - y0) * s),
    });
  }

  const pos = {};

  function drawMap() {
    const to = project();
    TRIP.places.forEach((p) => (pos[p.id] = to(p)));

    // subtle graticule
    const grid = [];
    for (let x = 60; x < MAP.w; x += 70) grid.push(`<path d="M${x} 0V${MAP.h}"/>`);
    for (let y = 50; y < MAP.h; y += 70) grid.push(`<path d="M0 ${y}H${MAP.w}"/>`);
    byId("mapGrid").innerHTML = `<g class="grat">${grid.join("")}</g>
      ${[
        { n: "FRANCE", lon: 6.3, lat: 47.45 },
        { n: "SWITZERLAND", lon: 7.7, lat: 46.9 },
        { n: "ITALY", lon: 9.9, lat: 45.62 },
        { n: "AUSTRIA", lon: 13.3, lat: 48.05 },
        { n: "GERMANY", lon: 10.15, lat: 48.05 },
      ]
        .map((c) => {
          const q = to(c);
          return `<text class="map-country" x="${q.x}" y="${q.y}">${c.n}</text>`;
        })
        .join("")}`;

    // routes as gentle arcs
    byId("mapRoutes").innerHTML = TRIP.route
      .map(([a, b, mode], i) => {
        const p = pos[a],
          q = pos[b];
        const mx = (p.x + q.x) / 2,
          my = (p.y + q.y) / 2;
        const dx = q.x - p.x,
          dy = q.y - p.y;
        const len = Math.hypot(dx, dy) || 1;
        const bow = mode === "day" ? 26 : 34;
        const cx = mx - (dy / len) * bow,
          cy = my + (dx / len) * bow;
        return `<path class="route ${mode}" style="--i:${i}" d="M${p.x} ${p.y} Q${cx} ${cy} ${q.x} ${q.y}"/>`;
      })
      .join("");

    // pins
    byId("mapPins").innerHTML = TRIP.places
      .map((p) => {
        const q = pos[p.id];
        const label = p.day ? p.day : "✈";
        const cls = ["pin", p.side ? "is-side" : "", p.kind === "air" ? "is-air" : ""].join(" ");
        return `<g class="${cls}" data-place="${p.id}" ${p.day ? `data-day="${p.day}"` : ""}
            transform="translate(${q.x} ${q.y})" tabindex="0" role="button" aria-label="${p.name}">
            <circle class="pin-halo" r="18"/>
            <circle class="pin-dot" r="11"/>
            <text class="pin-num" y="4">${label}</text>
            <text class="pin-label" x="${p.ldx || 0}" y="${p.ldy || -20}">${p.name}</text>
          </g>`;
      })
      .join("");

    const svg = byId("routeSvg");
    const tip = byId("mapTip");

    // Draw the route only once it is on screen, so the animation is actually seen.
    new IntersectionObserver(
      (entries, obs) =>
        entries.forEach((en) => {
          if (!en.isIntersecting) return;
          byId("mapRoutes").classList.add("is-live");
          obs.disconnect();
        }),
      { threshold: 0.25 }
    ).observe($(".map-canvas"));

    svg.addEventListener("mousemove", (e) => {
      const g = e.target.closest(".pin");
      if (!g) {
        tip.hidden = true;
        return;
      }
      const p = TRIP.places.find((x) => x.id === g.dataset.place);
      const d = p.day ? TRIP.days.find((x) => x.n === p.day) : null;
      tip.innerHTML = `<b>${p.name}</b>${
        d ? `<span>Day ${d.n} · ${fmtDate(d.date)}</span><em>${d.subtitle}</em>` : "<span>Arrival airport</span>"
      }`;
      const r = svg.getBoundingClientRect();
      tip.style.left = `${e.clientX - r.left}px`;
      tip.style.top = `${e.clientY - r.top}px`;
      tip.hidden = false;
    });
    svg.addEventListener("mouseleave", () => (tip.hidden = true));

    const activate = (g) => {
      if (g && g.dataset.day) openDay(+g.dataset.day);
    };
    svg.addEventListener("click", (e) => activate(e.target.closest(".pin")));
    svg.addEventListener("keydown", (e) => {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        activate(e.target.closest(".pin"));
      }
    });
  }

  function syncMapDim(visibleDayNumbers) {
    const on = new Set(visibleDayNumbers);
    const filtering = on.size !== TRIP.days.length;
    $$("#mapPins .pin").forEach((g) => {
      const d = g.dataset.day;
      g.classList.toggle("is-dim", filtering && d && !on.has(+d));
    });
  }

  byId("seqList").addEventListener("click", (e) => {
    const btn = e.target.closest("[data-seq]");
    if (btn) openDay(+btn.dataset.seq);
  });

  byId("seqList").addEventListener("mouseover", (e) => {
    const btn = e.target.closest("[data-seq]");
    $$("#mapPins .pin").forEach((g) =>
      g.classList.toggle("is-hot", !!btn && g.dataset.day === btn.dataset.seq)
    );
  });
  byId("seqList").addEventListener("mouseleave", () =>
    $$("#mapPins .pin").forEach((g) => g.classList.remove("is-hot"))
  );

  /* ── Countdown ───────────────────────────────────────────────────────── */
  function tick() {
    const start = new Date(TRIP.startDate + "T08:00:00");
    const end = new Date(TRIP.endDate + "T23:59:59");
    const now = new Date();
    let target = start,
      label = "until departure";

    if (now >= start && now <= end) {
      const dayNo = Math.floor((now - start) / 86400000) + 1;
      label = `you're on day ${dayNo} of the trip`;
      target = end;
    } else if (now > end) {
      byId("countdown").classList.add("is-done");
      byId("cdLabel").textContent = "trip complete — countless memories";
      $$("[data-cd]").forEach((el) => (el.textContent = "✓"));
      return;
    }

    const diff = Math.max(0, target - now);
    const d = Math.floor(diff / 86400000);
    const h = Math.floor((diff / 3600000) % 24);
    const m = Math.floor((diff / 60000) % 60);
    const s = Math.floor((diff / 1000) % 60);
    const set = (k, v) => {
      const el = $(`[data-cd="${k}"]`);
      const txt = String(v).padStart(2, "0");
      if (el.textContent !== txt) {
        el.textContent = txt;
        el.classList.remove("bump");
        void el.offsetWidth;
        el.classList.add("bump");
      }
    };
    set("days", d);
    set("hours", h);
    set("mins", m);
    set("secs", s);
    byId("cdLabel").textContent = label;
  }

  /* ── Theme ───────────────────────────────────────────────────────────── */
  const THEME_KEY = "europe2026.theme";
  function applyTheme(t) {
    document.documentElement.dataset.theme = t;
    localStorage.setItem(THEME_KEY, t);
  }
  function toggleTheme() {
    applyTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark");
  }
  applyTheme(
    localStorage.getItem(THEME_KEY) ||
      (window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light")
  );
  byId("themeBtn").addEventListener("click", toggleTheme);
  byId("printBtn").addEventListener("click", () => window.print());

  /* ── Scroll behaviour ────────────────────────────────────────────────── */
  const bar = byId("scrollBar");
  const toTop = byId("toTop");
  function onScroll() {
    const h = document.documentElement.scrollHeight - window.innerHeight;
    bar.style.width = `${Math.min(100, (window.scrollY / (h || 1)) * 100)}%`;
    byId("siteHeader").classList.toggle("is-stuck", window.scrollY > 40);
    toTop.hidden = window.scrollY < 600;
  }
  window.addEventListener("scroll", onScroll, { passive: true });
  toTop.addEventListener("click", () => window.scrollTo({ top: 0, behavior: "smooth" }));

  let io;
  function observeReveals() {
    if (!io) {
      io = new IntersectionObserver(
        (entries) =>
          entries.forEach((en) => {
            if (en.isIntersecting) {
              en.target.classList.add("in");
              io.unobserve(en.target);
            }
          }),
        { rootMargin: "0px 0px -8% 0px", threshold: 0.05 }
      );
    }
    $$(".reveal:not(.in)").forEach((el) => io.observe(el));
  }

  /* ── Deep links: index.html#day-6 opens that day ─────────────────────── */
  function openFromHash() {
    const m = location.hash.match(/^#day-(\d+)$/);
    if (m) openDay(+m[1]);
  }
  window.addEventListener("hashchange", openFromHash);

  /* ── Boot ────────────────────────────────────────────────────────────── */
  if (new URLSearchParams(location.search).get("view") === "timeline") {
    state.view = "timeline";
    $$(".view-toggle button").forEach((b) => b.classList.toggle("is-active", b.dataset.view === "timeline"));
  }

  renderStatics();
  renderPack();
  renderDays();
  drawMap();
  tick();
  setInterval(tick, 1000);
  onScroll();
  observeReveals();
  openFromHash();
})();
