# 14-Day Europe Itinerary — Interactive Webpage

An interactive companion to the trip poster: France → Switzerland → Italy → Austria → Germany,
3–14 September 2026.

## Running it

No build step and no dependencies. Open `index.html` in any modern browser.

To serve it locally instead (useful on a phone on the same Wi-Fi):

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## What's interactive

- **Live countdown** to departure that switches to "you're on day N" during the trip.
- **12 day cards** — click (or focus and press Enter) any card to open the full day: schedule,
  activities, travel legs with durations, overnight stop and a practical note.
- **Modal navigation** with the on-screen buttons or `←` / `→`; `Esc` closes.
- **Search and country filters** — filter by any city, sight or train, or by country. Filtering
  also dims the non-matching pins on the route map.
- **Two layouts** — card grid or vertical timeline.
- **Route map** drawn from real coordinates (Mercator projection). Hover a pin for a preview,
  click it to open that day. The route animates as it scrolls into view.
- **Packing checklist** saved to `localStorage`, with a progress bar.
- **Dark mode** (button, or press `T`), following your system preference by default.
- **Print / save as PDF** with a layout tuned for paper.

### Keyboard shortcuts

| Key | Action |
| --- | --- |
| `/` | Focus search |
| `T` | Toggle dark mode |
| `←` `→` | Previous / next day (while a day is open) |
| `Esc` | Close the day |

### Shareable links

- `index.html#day-6` opens day 6 directly.
- `index.html?view=timeline` loads the timeline layout.

## Files

| File | Purpose |
| --- | --- |
| `index.html` | Page structure |
| `styles.css` | All styling, theming, responsive and print rules |
| `data.js` | The itinerary itself — edit this to change the trip |
| `app.js` | Rendering, filtering, modal, map projection, countdown |

## Editing the itinerary

Everything shown on the page comes from `TRIP` in `data.js`. To change a day, edit its entry in
`TRIP.days`:

- `activities` renders as a bullet list; use `schedule` instead (`{ time, text }`) for a timed day.
- `legs` accepts modes `train`, `bus`, `plane` and `day`, each with optional `duration`.
- `theme` picks the illustration: `lake`, `peak`, `rail`, `city`, `water`, `town`, `baroque`, `castle`.

Map pins come from `TRIP.places` (latitude / longitude, with optional `ldx` / `ldy` to nudge a
label), and the lines between them from `TRIP.route`.

## Note on dates

The poster's weekdays match September 2025, but its dates and "best time to travel" say
September 2026. This page uses **2026**, so weekdays are calculated for that year — 3 September
2026 is a Thursday. Change `startDate` / `endDate` and the `date` fields in `data.js` if the trip
is actually 2025.
